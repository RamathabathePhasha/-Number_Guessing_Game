import random

chances = 0
number = random.randint(1, 100)

print("Welcome to the Number Guessing Game")
print("I'm thinking of a number between 1 and 100")

difficulty = input("Choose difficulty type ('Easy' or 'Hard'):")

if difficulty == 'Easy':
    chances = 10
elif difficulty == 'Hard':
    chances = 5
else:
    chances = 0
    print("Invalid option")

while chances > 0:
    print(f"You have {chances} attempts remaining to guess the number")
    
    guess = int(input("Make a guess: "))

    if guess == number:
        print(f"You got it! The answer is {number}")
        chances = 0
    elif guess < number:
        print("Too low. Guess again.")
        chances -= 1
    elif guess > number:
        print("Too high. Guess again.")
        chances -= 1

if chances == 0:
    print(f"You have run out of chances. You lose. The number was {number}")


